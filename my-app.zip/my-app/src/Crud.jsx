  import React, { useEffect, useState } from "react";
  import "./style.css";

  const AddData = ({userData}) => {
    const [name, setName] = useState("");
    const [phone, setPhone] = useState("");
    const [record, setRecord] = useState([]);

    const handelSubmit = e => {
      e.preventDefault();

      if (!name || !phone) {
        alert("Please Enter Input");
      }

      let obj = {
        id: Math.floor(Math.random() * 1000),
        name,
        phone
      };

      let oldData = [...record, obj];
      setRecord(oldData);
      localStorage.setItem("users", JSON.stringify(oldData));

      setName("");
      setPhone("");

      let user = JSON.parse(localStorage.getItem('users'))
      userData(user)
    };

    useEffect(() => {
      let allData = localStorage.getItem("users")
        ? JSON.parse(localStorage.getItem("users"))
        : [];
      setRecord(allData);
    }, []);

    return (
      <div>
        <div className="form-box">
          <form onSubmit={handelSubmit} align="center" className="form-data">
            <h3>Add User</h3>
            <hr />
            <input
              type="text"
              onChange={e => setName(e.target.value)}
              placeholder="Enter Name"
              value={name}
            />
            <br />
            <br />
            <input
              type="text"
              onChange={e => setPhone(e.target.value)}
              value={phone}
              placeholder="Enter Phone"
            />
            <br />
            <br />
            <button type="submit">Add User</button>
            <br />
            <br />
          </form>
        </div>
        
      </div>
    );
  };

  export default AddData;
