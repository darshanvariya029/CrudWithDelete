import { useEffect, useState } from "react";
import Table from "react-bootstrap/Table";
import AddData from "./Crud";

function App() {
  const [record,setRecord] = useState(JSON.parse(localStorage.getItem('users')) || [])

  const userdata = (data) =>{
      setRecord(data)
  }
  const deleteUser = (id) => {
    let data = record.filter(item => item.id !== id);
    setRecord(data);
    localStorage.setItem('users', JSON.stringify(data));
  };

  useEffect(() => {
    userdata(record); 
  }, [record]);


  return (
    <div>
      <AddData userData={userdata}  />
      <Table className="table-box" striped bordered hover>
        <thead>
          <tr>
            <th>No.</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {
          record.map((val, i) => {
            return (
              <tr>
                <td>
                  {val.id}
                </td>
                <td>
                  {val.name}
                </td>
                <td>
                  {val.phone}
                </td>
                <td>
                  <button type="submit" onClick={ () => deleteUser(val.id)}>Delete</button>
              
                </td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
}

export default App;
